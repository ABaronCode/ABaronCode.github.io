Working repository to be posted to my github pages once features work and are presentable.
Website to hold my resume, intrests and highlight my past experiances, links to old projects and demonstration of self-learning of html, css, javascript and node features in a website.
